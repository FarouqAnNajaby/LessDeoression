package com.example.less_depression.Model;

public class DataModelHistory {

    private String kode_history;
    private int id_pengguna;

    public String getKode_history() {
        return kode_history;
    }

    public void setKode_history(String kode_history) {
        this.kode_history = kode_history;
    }

    public int getId_pengguna() {
        return id_pengguna;
    }

    public void setId_pengguna(int id_pengguna) {
        this.id_pengguna = id_pengguna;
    }
}
