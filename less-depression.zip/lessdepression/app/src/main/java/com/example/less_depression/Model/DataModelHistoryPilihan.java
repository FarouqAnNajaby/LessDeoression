package com.example.less_depression.Model;

public class DataModelHistoryPilihan {

    private String kode_history;
    private String kode_gejala;

    public String getKode_history() {
        return kode_history;
    }

    public void setKode_history(String kode_history) {
        this.kode_history = kode_history;
    }

    public String getKode_gejala() {
        return kode_gejala;
    }

    public void setKode_gejala(String kode_gejala) {
        this.kode_gejala = kode_gejala;
    }
}
